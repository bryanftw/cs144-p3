*Step 1*

Sellers (UserID, Rating, Location, Country, Latitude, Longitude) Primary Key: UserID

Bidders (UserID, Rating, Location, Country) Primary Key: UserID

Items (ItemID, Name, SellerID, Started, Ends, FirstBid, Currently, NumberOfBids, BuyPrice, Description) Primary Key: ItemID

Bids (ItemID, BidderID, Amount, Time) Primary Key: (ItemID, Amount)

ItemCategories (ItemID, Category) Primary Key: (ItemID, Category)

*Step 2*

Completely nontrivial functional dependencies:

Sellers table:
UserID -> Rating
UserID -> Location
UserID -> Country
UserID -> Latitude
UserID -> Longitude

Plus all combinations of the above [e.g. UserID -> (Location, Latitude)] 
excluding UserID -> (Rating, Location, Country, Latitude, Longitude)

Bidders table:
UserID -> Rating
UserID -> Location
UserID -> Country
UserID -> Rating, Location
UserID -> Rating, Country
UserID -> Location, Country

Items table:
ItemID -> Name
ItemID -> Description  
ItemID -> SellerID 
ItemID -> Started
ItemID -> Ends
ItemID -> First_Bid
ItemID -> Currently
ItemID -> Number_of_Bids
ItemID -> Buy_Price

Plus all combinations of the above [e.g. ItemID -> (SellerID, Started, Ends)] 
excluding ItemID -> (Name, Description, SellerID, Started, Ends, First_Bid, Currently, Number_of_Bids, Buy_Price)

Number_of_Bids -> Currently

Bids table:
ItemID -> BidderID 
ItemID -> Amount
ItemID -> Time  
ItemID -> Amount, Time
ItemID -> Amount, BidderID
ItemID -> Time, BidderID

*Step 3* 

Since Number_of_Bids -> Currently is a functional dependency and Number_of_Bids isn't a super key, our schema
isn't in BCNF. However, I would argue that it's not worth changing the schema. The only constraints are that
(Number_of_Bids == 0) <=> (Currently == First_Bid) and (Number_of_Bids != 0) <=> (Currently != First_Bid),
and it's unlikely that an inconsistency would be introduced into the database, since it wouldn't make sense to update a 
value for one of those attributes without updating the other, besides the fact that the database is a historical snapshot 
and probably shouldn't need to be updated anyways. In terms of performance, both of these attributes are something that 
would commonly be asked for when looking for the status of an auction, and splitting the table into two would slow down 
these requests.


*Step 4*

Since it isn't in BCNF, it isn't in 4NF, and our argument for this is the same as above.