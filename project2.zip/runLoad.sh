#!/bin/bash

mysql CS144 < drop.sql
mysql CS144 < create.sql

ant
ant -f build.xml run-all

sort sellers.dat | uniq > usellers.dat
sort bidders.dat | uniq > ubidders.dat
sort items.dat | uniq > uitems.dat
sort bids.dat | uniq > ubids.dat
sort itemCategories.dat | uniq > uitemCategories.dat

mysql CS144 < load.sql

rm *.dat
rm -rf bin
