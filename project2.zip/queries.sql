-- 13422
SELECT
	(SELECT COUNT(*) FROM Sellers)+
	(SELECT COUNT(*) FROM Sellers
	RIGHT JOIN Bidders ON Sellers.UserID = Bidders.UserID
	WHERE Sellers.UserID IS NULL)
AS UserCount;

-- 103
SELECT COUNT(*)
FROM Sellers INNER JOIN Items
ON Sellers.UserID = Items.SellerID
WHERE BINARY Location = 'New York';

-- 8365
SELECT COUNT(*)
FROM
(SELECT COUNT(*) as C FROM ItemCategories
        GROUP BY ItemID
        HAVING C = 4)
as AuctionsWith4Categories;

-- 1046740686
SELECT Bids.ItemID
FROM Bids INNER JOIN Items
ON Bids.ItemID = Items.ItemID
WHERE Ends > '2001-12-20 00:00:01'
AND Amount = (SELECT MAX(Amount) FROM Bids);

-- 3130
SELECT COUNT(*)
FROM Sellers
WHERE Rating > 1000;

-- 6717
SELECT
	(SELECT COUNT(*) FROM Sellers RIGHT JOIN Bidders 
	ON Sellers.UserID = Bidders.UserID)-
	(SELECT COUNT(*) FROM Sellers RIGHT JOIN Bidders 
	ON Sellers.UserID = Bidders.UserID
	WHERE Sellers.UserID IS NULL)
AS UserCount;

-- 150
SELECT COUNT(DISTINCT Category)
FROM ItemCategories INNER JOIN Bids
ON ItemCategories.ItemID = Bids.ItemID
WHERE Amount > 100
AND Bids.ItemID IN
	(SELECT Bids.ItemID
	FROM Items INNER JOIN Bids
	ON Bids.ItemID = Items.ItemID);
